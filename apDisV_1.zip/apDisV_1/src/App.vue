<template>
    <div id="app">
        <div id="navDivContainer" class="navDivContainer">
            <div v-if="logInorNot == true">
                <TopNavMenu />
            </div>
        </div>
        <div id="bodyContainer" class="bodyContainer">
            <router-view></router-view>
        </div>
    </div>
</template>

<script>
import TopNavMenu from "./components/navMenu/TopNavMenu.vue";
export default {
    name: "App",
    components: {
        TopNavMenu,
    },
    data() {
        return {
            logInorNot: "",
        };
    },
    beforeMount() {
        var token = localStorage.getItem("token");
        if (token == null) {
            this.logInorNot = false;
            this.$router.push({
                path: "/login",
            });
        } else {
            var data = {
                token: token,
            };
            this.axios
                .post("signup/v1/userInfo", data)
                .then(() => {
                    this.logInorNot = true;
                })
                .catch((err) => {
                    this.logInorNot = false;
                    localStorage.clear();
                    this.$router.push({
                        path: "/login",
                    });
                });
        }
    },
    created() {
        console.log("created");
        window.addEventListener("beforeunload", this.clearLocalStorage);
    },
    mounted() {
        var self = this;
        self.appHt();
        window.addEventListener(
            "resize",
            function () {
                self.appHt();
            },
            true
        );
    },
    methods: {
        appHt: function () {
            var h = window.innerHeight,
                navDivContainerHt = document.getElementById("navDivContainer")
                    .offsetHeight;
            document.getElementById("bodyContainer").style.height =
                parseFloat(h) - parseFloat(navDivContainerHt) - 10 + "px";
        },
    },
    clearLocalStorage() {
        localStorage.clear();
    },
};
</script>

<style>
#app {
    font-family: Avenir, Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    color: #2c3e50;
}
</style>
