import Vue from 'vue'
import App from './App.vue'
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'
import router from './components/Router/Router'
import VueRouter from 'vue-router'
import VueSimpleAlert from "vue-simple-alert";
import { mdbDatatable } from 'mdbvue';
import { BootstrapVue, IconsPlugin } from "bootstrap-vue";
import './axios'

import axios from 'axios'
import VueAxios from 'vue-axios'



Vue.use(VueAxios, axios)
Vue.use(require('vue-resource'));
Vue.use(BootstrapVue)
Vue.use(mdbDatatable)
Vue.use(VueSimpleAlert)
Vue.use(IconsPlugin)
Vue.use(VueRouter);
// Vue.config.productionTip = false


new Vue({
    router,
    render: h => h(App),
}).$mount('#app')