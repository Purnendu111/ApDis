<template>
    <div>
        <b-nav toggleable="lg">
            <b-nav-item>
                <router-link to="/"
                    ><img src="../../assets/aplogo.png" height="50" width="50"
                /></router-link>
            </b-nav-item>
            <b-nav-item-dropdown
                id="my-nav-dropdown"
                text="API Initiate"
                class="paddingtop10"
                toggle-class="nav-link-custom"
                offset="15"
            >
                <b-dropdown-item href="/Questionnaire">Initiate</b-dropdown-item>
                <b-dropdown-divider></b-dropdown-divider>
                <b-dropdown-item v-if="this.type == 'admin'" href="/exceptionList"
                    >Exception List</b-dropdown-item
                >
                <b-dropdown-divider v-if="this.type == 'admin'"></b-dropdown-divider>
                <b-dropdown-item href="/myapilist">My Apis</b-dropdown-item>
            </b-nav-item-dropdown>
            <b-nav-item-dropdown
                id="my-nav-dropdown"
                text="API Design"
                class="paddingtop10"
                toggle-class="nav-link-custom"
                offset="15"
            >
                <b-dropdown-item
                    ><router-link to="/api_linter">
                        Validate API
                    </router-link></b-dropdown-item
                >
            </b-nav-item-dropdown>
            <b-nav-item-dropdown
                id="my-nav-dropdown"
                :text="userName"
                class="paddingtop10 ml-auto"
                toggle-class="nav-link-custom"
                right
                offset="-15"
            >
                <b-dropdown-item
                    ><router-link to="#">Profile</router-link></b-dropdown-item
                >
                <b-dropdown-divider></b-dropdown-divider>
                <b-dropdown-item v-on:click="logout">Logout</b-dropdown-item>
            </b-nav-item-dropdown>
        </b-nav>
    </div>
</template>

<script>
export default {
    name: "TopNavMenu",
    data() {
        return {
            userName: "",
            type: "",
        };
    },
    mounted() {
        this.getUserDetails();
    },
    methods: {
        getUserDetails() {
            var token = localStorage.getItem("token");
            var data = {
                token: token,
            };
            this.axios.post("signup/v1/userInfo", data).then((res) => {
                console.log(JSON.stringify(res));
                this.userName = res.data.data.fullname;
                this.type = res.data.data.type;
            });
        },
        logout: function () {
            var token = localStorage.getItem("token");
            var data = {
                token: token,
            };
            this.axios.post("signup/v1/logout", data).then((res) => {
                if (res.status == 200) {
                    localStorage.clear();
                    window.location.href = "/login";
                }
            });
        },
    },
};
</script>
