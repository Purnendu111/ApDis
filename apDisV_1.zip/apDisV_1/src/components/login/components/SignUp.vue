<template>
    <div class="signUp">
        <form
            id="signUpForm"
            ref="form"
            @submit.prevent="submitData"
            method="post"
            action=""
        >
            <div class="tableCstm">
                <div class="tr">
                    <div class="td" style="width: 100% !important">
                        <div role="group">
                            <label for="name" class="whiteText paddingBottom10"
                                >Name:</label
                            >
                            <b-form-input
                                id="name"
                                name="fullname"
                                placeholder="Enter your Name"
                                trim
                                class="input"
                            ></b-form-input>
                            <div id="errorName"></div>
                        </div>
                    </div>
                </div>

                <div class="tr">
                    <div class="td" style="width: 100% !important">
                        <div role="group">
                            <label for="emp-id" class="whiteText paddingBottom10"
                                >Employee ID:</label
                            >
                            <b-form-input
                                id="emp_id"
                                name="username"
                                placeholder="Enter your Employee ID"
                                trim
                                class="input"
                            ></b-form-input>
                            <div id="errorEmpId"></div>
                        </div>
                    </div>
                </div>

                <div class="tr">
                    <div class="td" style="width: 100% !important" id="app">
                        <div role="group">
                            <label for="domain" class="whiteText paddingBottom10"
                                >Domain:</label
                            >
                            <div>
                                <b-form-select
                                    id="domain"
                                    text="Select Domain"
                                    name="domain"
                                    class="input paddingLeft10"
                                    menu-class="w-100"
                                    v-model="domain"
                                >
                                    <b-form-select-option :value="null"
                                        >Please select Domain</b-form-select-option
                                    >
                                    <b-form-select-option
                                        v-for="item in domainData"
                                        v-bind:key="item._id"
                                        menu-class="w-100"
                                        :value="item.domainname"
                                        >{{ item.domainname }}</b-form-select-option
                                    >
                                </b-form-select>
                                <div id="errorDomain"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="tr">
                    <div class="td" style="width: 100% !important">
                        <div role="group">
                            <label for="email" class="whiteText paddingBottom10"
                                >Email:</label
                            >
                            <b-form-input
                                id="email"
                                name="email"
                                placeholder="Enter your email"
                                trim
                                class="input"
                            ></b-form-input>
                            <div id="errorEmail"></div>
                        </div>
                    </div>
                </div>
                <div class="tr">
                    <div class="td" style="width: 100% !important">
                        <div nrole="group">
                            <label for="password" class="whiteText paddingBottom10"
                                >Password:</label
                            >
                            <b-form-input
                                id="password"
                                type="password"
                                name="password"
                                placeholder="***********"
                                trim
                                class="input"
                            ></b-form-input>
                            <div id="errorPassword"></div>
                        </div>
                    </div>
                </div>

                <div class="tr">
                    <div class="td" style="width: 100% !important">
                        <div nrole="group">
                            <label for="cpassword" class="whiteText paddingBottom10"
                                >Confirm Password:</label
                            >
                            <b-form-input
                                id="cpassword"
                                type="password"
                                placeholder="***********"
                                trim
                                class="input"
                            ></b-form-input>
                            <div id="errorCPassword"></div>
                        </div>
                    </div>
                </div>

                <div class="tr">
                    <div class="td" style="width: 100% !important">
                        <span style="padding-right: 10px">
                            <input type="checkbox" id="tNc" name="TnC" value="true" />
                        </span>
                        <span class="whiteText"> I agree the Terms and Conditions</span>
                        <div id="errorTnC"></div>
                    </div>
                </div>
                <div class="tr">
                    <div class="td" style="width: 100% !important">
                        <b-button style="width: 25%" variant="primary" type="submit"
                            >Sign Up</b-button
                        >
                        <div id="message"></div>
                    </div>
                </div>

                <div class="tr">
                    <div class="td" style="width: 100% !important">
                        <span class="whiteText">Already have an account </span
                        ><a href="javascript:void(0);" class="aSignIn"
                            ><span id="backToSignUp" class="whiteText" v-on:click="signIn"
                                >Sign In</span
                            ></a
                        >
                    </div>
                </div>
            </div>
        </form>
    </div>
</template>

<script>
export default {
    name: "SignUp",
    props: {
        method: { type: Function },
    },
    data() {
        var self = this;
        var signIn = self.method;
        return {
            signIn,
            domain: null,
            domainData: "",
        };
    },
    beforeMount() {
        this.axios
            .get("signup/v1/domain", {
                // method: "GET",
                mode: "no-cors",
                header: {
                    "Access-Control-Allow-Origin": "*",
                },
            })
            .then((response) => {
                this.domainData = response.data;
                console.log(this.domainData);
            });
    },
    methods: {
        formDataValidation() {
            let name = document.getElementById("name"),
                emp_id = document.getElementById("emp_id"),
                domain = document.getElementById("domain"),
                emailVal = document.getElementById("email"),
                password = document.getElementById("password"),
                cpassword = document.getElementById("cpassword");
        },
        submitData() {
            // this.formDataValidation();
            const formData = new FormData(this.$refs["form"]); // reference to form element
            const data = {}; // need to convert it before using not with XMLHttpRequest
            for (let [key, val] of formData.entries()) {
                Object.assign(data, { [key]: val });
            }
            console.log(data);
            this.axios.post("signup/v1/signup", data).then((res) => {
                if ((res.data = "Success")) {
                    alert("Signed up SuccessFull welcome to Ap Discover");
                    document.getElementById("signUpForm").reset();
                    document.getElementById("backToSignUp").click();
                }
            });
        },
    },
};
</script>
