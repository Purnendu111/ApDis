<style>
@import "../../../css/index.css";
</style>

<template>
    <div class="hello">
        <div class="masterDiv ht" id="masterDiv">
            <div class="tableCstm">
                <div class="tr">
                    <div class="td leftDiv" id="htLeft" style="width: 50%">
                        <center>
                            <div class="tableCstm">
                                <div class="tr">
                                    <div
                                        class="td"
                                        id="SignInUpmenu"
                                        style="width: 100% !important"
                                    >
                                        <label class="textHeading">
                                            <h3 class="slogan">
                                                Welcome To API Junction
                                            </h3>
                                        </label>
                                    </div>
                                </div>
                                <div class="tr">
                                    <div
                                        id="img_head"
                                        class="img_head td"
                                        style="width: 50%"
                                    >
                                        <img
                                            src="../../../assets/aplogo.png"
                                            height="200"
                                            width="200"
                                        />
                                    </div>
                                </div>
                            </div>
                        </center>
                    </div>
                    <div id="htRight" class="td rightDiv" style="width: 50%">
                        <div id="signIn_Up">
                            <div class="tableCstm">
                                <div class="tr">
                                    <div
                                        class="td padding_bottom_0"
                                        id="SignIn_Up_menu"
                                        style="width: 100% !important"
                                    >
                                        <label class="whiteText">
                                            <ul>
                                                <li class="item whiteText">
                                                    <a
                                                        href="#"
                                                        id="signInMenu"
                                                        class="whiteText underline"
                                                        v-on:click="backToSignIn"
                                                        >Sign In</a
                                                    >
                                                </li>
                                                <li class="item whiteText">Or</li>
                                                <li class="item whiteText">
                                                    <a
                                                        href="#"
                                                        id="signUpMenu"
                                                        class="whiteText underline"
                                                        v-on:click="goToSingup"
                                                        >Sign Up</a
                                                    >
                                                </li>
                                            </ul>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <!-- Sign In Div -->
                            <div id="signInDiv">
                                <SignIn
                                    :goToSingup="goToSingup"
                                    :forgotPass="forgotPass"
                                />
                            </div>

                            <!-- Sing Up -->
                            <div id="signupDiv">
                                <SignUp :method="backToSignIn" />
                            </div>
                        </div>
                        <!-- Reset Password Div -->
                        <div id="resetPassDiv">
                            <ResetPass :method="backToSignInFromReset" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import SignIn from "./SignIn.vue";
import SignUp from "./SignUp.vue";
import ResetPass from "./ResetPass.vue";
export default {
    name: "SignInSignUpReset",
    components: {
        SignIn,
        SignUp,
        ResetPass,
    },
    mounted() {
        document.getElementById("resetPassDiv").style.display = "none";
        document.getElementById("signupDiv").style.display = "none";
        var self = this;
        self.screenHt();
        window.addEventListener(
            "resize",
            function () {
                self.screenHt();
            },
            true
        );
    },
    methods: {
        screenHt: function () {
            var h = window.innerHeight,
                navDivContainerHt = document.getElementById("navDivContainer")
                    .offsetHeight;
            document.getElementById("htRight").style.height =
                parseFloat(h) - parseFloat(navDivContainerHt) - 10 + "px";
        },
        goToSingup: function () {
            document.getElementById("resetPassDiv").style.display = "none";
            document.getElementById("signInDiv").style.display = "none";
            document.getElementById("signupDiv").style.display = "block";
        },

        forgotPass: function () {
            document.getElementById("resetPassDiv").style.display = "block";
            document.getElementById("signIn_Up").style.display = "none";
        },

        backToSignInFromReset: function () {
            document.getElementById("resetPassDiv").style.display = "none";
            document.getElementById("signIn_Up").style.display = "block";
        },

        backToSignIn: function () {
            document.getElementById("resetPassDiv").style.display = "none";
            document.getElementById("signInDiv").style.display = "block";
            document.getElementById("signupDiv").style.display = "none";
        },
    },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
    margin: 40px 0 0;
}
ul {
    list-style-type: none;
    padding: 0;
}
li {
    display: inline-block;
    margin: 0 10px;
}
a {
    color: #42b983;
}
</style>
