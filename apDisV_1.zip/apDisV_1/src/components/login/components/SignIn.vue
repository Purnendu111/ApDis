<template>
    <div class="signIn">
        <form id="signInForm" @submit.prevent="signIn" method="post" action="">
            <div class="tableCstm">
                <div class="tr">
                    <div class="td" style="width: 100% !important">
                        <div role="group">
                            <label for="email" class="whiteText paddingBottom10"
                                >Email:</label
                            >
                            <b-form-input
                                id="email"
                                v-model="data.email"
                                placeholder="Enter your email"
                                trim
                                class="input"
                            ></b-form-input>
                        </div>
                    </div>
                </div>
                <div class="tr">
                    <div class="td" style="width: 100% !important">
                        <div nrole="group">
                            <label for="password" class="whiteText paddingBottom10"
                                >Password:</label
                            >
                            <b-form-input
                                id="password"
                                v-model="data.password"
                                type="password"
                                placeholder="***********"
                                trim
                                class="input"
                            ></b-form-input>
                        </div>
                    </div>
                </div>
                <div class="tr">
                    <div class="td" style="width: 100% !important">
                        <b-button style="width: 25%" type="submit" variant="primary"
                            >Sign In</b-button
                        >
                        <a href="javascript:void(0);" v-on:click="goToResetPassFun">
                            <b-button
                                class="margin10"
                                style="width: 38%"
                                variant="warning"
                                >Reset Your Password</b-button
                            ></a
                        >
                    </div>
                </div>
                <div class="tr">
                    <div class="td" style="width: 100% !important">
                        <span class="whiteText">Don't have an account? </span
                        ><a
                            href="javascript:void(0);"
                            class="aSignIn"
                            v-on:click="goToSingup"
                            ><span class="whiteText">Sign Up</span></a
                        >
                    </div>
                </div>
            </div>
        </form>
    </div>
</template>

<script>
export default {
    name: "SignIn",
    props: {
        goToSingup: { type: Function },
        forgotPass: { type: Function },
    },
    data() {
        var self = this;
        var goToSingupFun = self.goToSingup;
        var goToResetPassFun = self.forgotPass;
        return {
            goToSingupFun,
            goToResetPassFun,
            data: {
                email: "",
                password: "",
            },
        };
    },
    methods: {
        signIn: function () {
            var dataCol = this.data;
            if (dataCol.email == "") {
                alert("Please Enter Email");
            } else if (dataCol.password == "") {
                alert("Please Enter Password");
            } else {
                this.axios.post("signup/v1/signin", dataCol).then((res) => {
                    if (res.status == 200) {
                        localStorage.setItem("token", res.data.token);
                        window.location.href = "/questionnaire";
                    }
                    console.log(res);
                });
            }
        },
    },
};
</script>
