<template>
    <div class="signIn">
        <div class="tableCstm">
            <div class="tr">
                <div class="td" id="SignInUpmenu" style="width: 100% !important">
                    <label class="whiteText">
                        <ul>
                            <li class="item whiteText">
                                <a href="#" id="signInMenu" class="whiteText underline"
                                    >Reset Password</a
                                >
                            </li>
                        </ul>
                    </label>
                </div>
            </div>
            <div class="tr">
                <div class="td" style="width: 100% !important">
                    <div role="group">
                        <label for="email" class="whiteText paddingBottom10"
                            >Email:</label
                        >
                        <b-form-input
                            id="email"
                            v-model="email"
                            placeholder="Enter your email"
                            trim
                            class="input"
                        ></b-form-input>
                    </div>
                </div>
            </div>
            <div class="tr">
                <div class="td" style="width: 100% !important">
                    <b-button style="width: auto%" variant="primary" type="reset"
                        >Send Reset Password Link</b-button
                    >
                </div>
            </div>
            <div class="tr">
                <div class="td" style="width: 100% !important">
                    <a
                        href="javascript:void(0);"
                        v-on:click="backToSignIn"
                        class="aSignIn"
                        ><span class="signUpInSignIn">Back To Sign In</span></a
                    >
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: "ResetPass",
    props: {
        method: { type: Function },
    },
    data() {
        var self = this;
        var backToSignIn = self.method;
        return {
            backToSignIn,
        };
    },
    methods: {},
};
</script>
