<template>
    <div class="accordion" role="">
        <b-card
            v-for="(items, i) in exceptionData"
            v-bind:key="items._id"
            no-body
            class=""
        >
            <b-card-header
                block
                v-b-toggle="items._id"
                header-tag="header"
                class="p-1"
                role="tab"
            >
                <b-button left variant="transparent">{{ items.api_name }}</b-button>
                <b-icon-arrow-down
                    style="
                        float: right !important;
                        margin-top: 10px !important;
                        margin-right: 20px !important;
                    "
                ></b-icon-arrow-down>
            </b-card-header>
            <b-collapse v-bind:id="items._id" accordion="my-accordion" role="">
                <b-card-body>
                    <b-card-text> <code> </code> <code> </code></b-card-text>
                    <b-card-text>Domain:{{ items.domain }}</b-card-text>
                    <b-card-text>Description:{{ items.desc }}</b-card-text>
                    <b-card-text>Exception Text:{{ items.exceptionDesc }}</b-card-text>
                    <b-button
                        variant="danger"
                        v-on:click="approveRejectAPI(items._id, 'rj')"
                        >Reject</b-button
                    >
                    <b-button
                        class="margin10"
                        variant="primary"
                        v-on:click="approveRejectAPI(items._id, 'su')"
                        >Approve</b-button
                    >
                </b-card-body>
            </b-collapse>
        </b-card>
    </div>
</template>

<script>
export default {
    name: "ExceptionList",
    data() {
        return {
            exceptionData: "",
        };
    },
    beforeMount() {
        var token = localStorage.getItem("token");
        if (token == null) {
            this.$router.push({
                path: "/login",
            });
        } else {
            var data = {
                token: token,
            };
            this.axios
                .post("signup/v1/userInfo", data)
                .then((res) => {
                    this.exceptionList();
                })
                .catch((err) => {
                    localStorage.clear();
                    this.$router.push({
                        path: "/login",
                    });
                });
        }
    },
    methods: {
        exceptionList() {
            this.axios
                .get("init/v1/getAPIExceptionList", {
                    // method: "GET",
                    mode: "no-cors",
                    header: {
                        "Access-Control-Allow-Origin": "*",
                    },
                })
                .then((response) => {
                    this.exceptionData = response.data;
                    console.log(this.exceptionData);
                });
        },
        approveRejectAPI(id, type) {
            var dataCol = {};
            dataCol["qId"] = id;
            dataCol["status"] = type;
            dataCol["callFrom"] = "";
            var token = localStorage.getItem("token");
            dataCol["token"] = token;
            console.log(dataCol);
            this.axios.post("init/v1/updateApiStatus", dataCol).then((res) => {
                console.log(res);
                this.$fire({
                    type: "success",
                    title: "Data saved Successfully",
                    showConfirmButton: false,
                    timer: 2000,
                }).then(() => {
                    this.exceptionList();
                });
            });
        },
    },
};
</script>
