<template>
    <div>
        <div class="questionnaire">
            <form
                ref="form"
                id="questionnaireForm"
                @submit.prevent="submitData"
                method="post"
            >
                <div class="tableCstm">
                    <div class="tr">
                        <div class="td" style="width: 100% !important">
                            <div class="tableCstm">
                                <div class="tr">
                                    <div
                                        class="td paddingright40"
                                        style="width: 50% !important"
                                    >
                                        <div role="group">
                                            <label for="API_name" class="paddingBottom10"
                                                >Please enter API name :</label
                                            >
                                            <b-form-input
                                                id="API_name"
                                                reqired
                                                @blur="checkApiName"
                                                name="api_name"
                                                v-model="dataModel.api_name"
                                                placeholder="e.g. Account API"
                                                trim
                                            ></b-form-input>
                                        </div>
                                    </div>
                                    <div class="td" style="width: 50% !important">
                                        <div role="group">
                                            <label for="API_name" class="paddingBottom10"
                                                >Domain :</label
                                            >
                                            <b-form-input
                                                id="domain"
                                                name="domain"
                                                v-model="dataModel.domain"
                                                placeholder="e.g. Customer"
                                                trim
                                            ></b-form-input>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tr">
                        <div class="td" style="width: 100% !important">
                            <div role="group">
                                <label for="API_name" class="paddingBottom10"
                                    >Description :</label
                                >
                                <b-form-textarea
                                    rows="4"
                                    no-resize
                                    id="desc"
                                    name="desc"
                                    v-model="dataModel.desc"
                                    placeholder="Mainly why do you think it an API? Who are the consumers?Internal/External"
                                    trim
                                ></b-form-textarea>
                            </div>
                        </div>
                    </div>
                    <div class="tr">
                        <div class="td" style="width: 100% !important">
                            <div class="hedding">Questionnaire:</div>
                            <div class="quest">
                                <div v-for="(items, i) in dataVal" v-bind:key="items.id">
                                    item-{{ items.question }}:<br />
                                    <!-- For Multiple select Option -->
                                    <div v-if="items.type === 'M'" class="checkbox">
                                        <b-form-checkbox
                                            class="marginright5"
                                            :name="'questions_' + items._id"
                                            v-for="(subitem, index1) in items.options"
                                            :value="subitem"
                                            :id="'que_' + items._id + '_' + subitem"
                                            v-bind:key="index1"
                                        >
                                            {{ subitem }}<br />
                                        </b-form-checkbox>
                                    </div>
                                    <!-- For Single select Option -->
                                    <div v-else class="radio">
                                        <b-form-radio
                                            class="marginright5"
                                            v-for="(subitem, index1) in items.options"
                                            :name="'questions_' + items._id"
                                            :value="subitem"
                                            :id="'que_' + items._id + '_' + subitem"
                                            v-bind:key="index1"
                                        >
                                            {{ subitem }}<br />
                                        </b-form-radio>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tr">
                        <div class="td" style="width: 100% !important">
                            <b-button variant="danger">Cancel</b-button>
                            <b-button
                                class="margin10"
                                id="save"
                                variant="primary"
                                type="submit"
                                >Submit</b-button
                            >
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</template>

<script>
export default {
    name: "Questionnaire",
    components: {},
    data() {
        return {
            dataVal: "",
            dataModel: {
                api_name: "",
                domain: "",
                desc: "",
            },
        };
    },
    beforeMount() {
        var token = localStorage.getItem("token");
        if (token == null) {
            this.$router.push({
                path: "/login",
            });
        } else {
            var data = {
                token: token,
            };
            this.axios
                .post("signup/v1/userInfo", data)
                .then(() => {
                    this.axios
                        .get("init/v1/questions", {
                            // method: "GET",
                            mode: "no-cors",
                            header: {
                                "Access-Control-Allow-Origin": "*",
                            },
                        })
                        .then((response) => {
                            this.dataVal = response.data;
                            console.log(this.dataVal);
                        });
                })
                .catch((err) => {
                    localStorage.clear();
                    this.$router.push({
                        path: "/login",
                    });
                });
        }
    },
    methods: {
        validateForm() {
            document.getElementById("save").blur();
            var apiname = document.getElementById("API_name"),
                domain = document.getElementById("domain"),
                desc = document.getElementById("desc");
            if (apiname.value == "") {
                this.$fire({
                    type: "error",
                    title: "Please enter API Name",
                    showConfirmButton: false,
                    timer: 2000,
                }).then(() => {
                    apiname.focus();
                });
                return false;
            } else if (domain.value == "") {
                this.$fire({
                    type: "error",
                    title: "Please enter Domain",
                    showConfirmButton: false,
                    timer: 2000,
                }).then(() => {
                    domain.focus();
                });
                return false;
            } else if (desc.value == "") {
                this.$fire({
                    type: "error",
                    title: "Please enter Description",
                    showConfirmButton: false,
                    timer: 2000,
                }).then(() => {
                    desc.focus();
                });
                return false;
            } else {
                var count = 0;
                for (let i = 0; i < this.dataVal.length; i++) {
                    var key = this.dataVal[i]._id;
                    var name = "questions_" + this.dataVal[i]._id;
                    let rbs = document.querySelectorAll('input[name="' + name + '"]');
                    for (const rb of rbs) {
                        if (rb.checked) {
                            count += 1;
                        }
                    }
                }
                if (count != 10) {
                    this.$fire({
                        type: "error",
                        title: "Please answer all question",
                        showConfirmButton: false,
                        timer: 2000,
                    });
                    return false;
                } else {
                    return true;
                }
            }
        },
        submitData() {
            var validation = this.validateForm();
            document.getElementById("save").disabled = true;
            if (!validation) {
                document.getElementById("save").disabled = false;
                return false;
            } else {
                let questionRes = [];
                for (let i = 0; i < this.dataVal.length; i++) {
                    var obj = {};
                    var options = this.dataVal[i].options;
                    var key = this.dataVal[i]._id;
                    for (let j = 0; j < options.length; j++) {
                        var id = "que_" + this.dataVal[i]._id + "_" + options[j];
                        if (document.getElementById(id).checked == true) {
                            var val = document.getElementById(id).value;
                            obj[key] = val;
                            questionRes.push(obj);
                        }
                    }
                }
                var dataCol = this.dataModel;
                dataCol["questionRes"] = questionRes;
                var token = localStorage.getItem("token");
                dataCol["token"] = token;
                console.log("data Collection" + JSON.stringify(dataCol));

                this.axios.post("init/v1/apiinit", dataCol).then((res) => {
                    console.log(res);
                    this.$fire({
                        type: "success",
                        title: "Data saved Successfully",
                        showConfirmButton: false,
                        timer: 2000,
                    }).then(() => {
                        document.getElementById("questionnaireForm").reset();
                        document.getElementById("save").disabled = false;
                        localStorage.setItem("questionnierId", res.data.id);
                        if (res.data.msg == "An API") {
                            this.$router.push({
                                path: "/api_linter",
                            });
                        } else {
                            localStorage.setItem("apiScore", res.data.score);

                            this.$router.push({
                                path: "/api_exception",
                            });
                        }
                    });
                });
            }
        },
        checkApiName() {
            var dataVal = {};
            dataVal["apiName"] = this.dataModel.api_name;
            var apiname = document.getElementById("API_name");
            this.axios.post("init/v1/findByAPI_Name", dataVal).then((res) => {
                if (res.status == 200) {
                    this.$fire({
                        type: "error",
                        title: "API Name already exsit",
                        showConfirmButton: false,
                        timer: 2000,
                    }).then(() => {
                        apiname.select();
                    });
                    return false;
                }
            });
        },
    },
};
</script>
