<template>
    <div>
        <b-card-group deck>
            <b-card
                v-for="item in 9"
                :key="item"
                border-variant="primary" 
                header="Domain:"
                header-bg-variant="primary" header-text-variant="white"
                title="Description : "
                :perpage="perpage"
                tag="article"
                style="min-width: 400px; max-width: 300px;"
                class="mb-2"
                >
                <b-card-text>
                    Some quick example text to build on the card title and make up the bulk of the card's content.
                </b-card-text>

                <b-button href="#" variant="primary">Try it now</b-button>

                <div id="App" class="container">
                    <div class="grid">
                        <article v-for="tool in tools.slice((currentPage-1)*perPage,(currentPage-1)*perPage+perPage)" :key=tool>
                        <div class="title">
                            <h3>{{tool.first_name}}</h3>
                        </div>
                        <div class="description">
                            {{tool.last_name}}
                        </div>
                        </article>
                    </div>
                </div>

            </b-card>

        </b-card-group>
        <b-pagination 
            v-model="currentPage" 
            :total-rows="tools.length" 
            :per-page="perPage" 
            first-text="First" prev-text="Prev" next-text="Next" last-text="Last">
        </b-pagination>
    </div>
</template>

<script>
export default {
    data() {
        return{
            loading:false,
        
            perPage: 8,
            currentPage: 1,
            tools: [
                    { id: 1,  },
                    { id: 2,  },
                    { id: 3,  },
                    { id: 4,  },
                    { id: 5,  },
                    { id: 6,  },
                    { id: 7,  },
                    { id: 8,  },
                    { id: 9,  },
                    { id: 1,  },
                    { id: 2,  },
                    { id: 3,  },
                    { id: 4,  },
                    { id: 5,  },
                    { id: 6,  },
                    { id: 7,  },
                    { id: 8,  },
                    { id: 9,  },
                    { id: 1,  },
                    { id: 2,  },
                    { id: 3,  },
                    { id: 4,  },
                    { id: 5,  },
                    { id: 6,  },
                    { id: 7,  },
                    { id: 8,  },
                    { id: 9,  },
                    { id: 1, first_name: ' Some quick example text' },
                    { id: 2, first_name: ' Some quick example text' },
                    { id: 3, first_name: ' Some quick example text' },
                    { id: 4, first_name: ' Some quick example text' },
                    { id: 5, first_name: ' Some quick example text' },
                    { id: 6, first_name: ' Some quick example text' },
                    { id: 7, first_name: ' Some quick example text' },
                    { id: 8, first_name: ' Some quick example text' },
                    { id: 9, first_name: ' Some quick example text' }
                ]
        }
                
    },
    computed: {
        rows() {
          return this.items.length
        },
        
      }
}
</script>