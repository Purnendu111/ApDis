<template>
    <div class="api_except">
        <center>
            <div class="tableCstm" style="width: 70% !important">
                <div class="tr">
                    <div class="td">
                        <div class="api_except_result">
                            <h3>Result from API Validation</h3>
                            <br />
                            <h4>Your API's Score is : {{ score }}</h4>
                            <h4>Your API did not qualify minimum requirements</h4>
                        </div>
                    </div>
                </div>
                <div class="tr">
                    <div class="td">
                        <div
                            class="api_except_result_button"
                            style="width: 100% !important"
                        >
                            <b-button
                                class="margin10"
                                variant="primary"
                                v-on:click="showExceptionMessage"
                                >Apply Exception</b-button
                            >
                        </div>
                    </div>
                </div>
            </div>
            <div id="resion_message" class="tableCstm" style="width: 70% !important">
                <div class="tr">
                    <div class="td" style="width: 100% !important">
                        <div role="group">
                            <label
                                for="API_name"
                                style="float: left"
                                class="paddingBottom10"
                                >Why do you think this is an API:</label
                            >
                            <b-form-textarea
                                rows="8"
                                no-resize
                                id="apiExcDesc"
                                v-model="data.exceptionDesc"
                                trim
                            ></b-form-textarea>
                            <b-button
                                class="margin10"
                                style="float: right"
                                variant="primary"
                                v-on:click="applyException"
                                id="applyException"
                                >Submit</b-button
                            >
                        </div>
                    </div>
                </div>
            </div>
        </center>
    </div>
</template>

<script>
export default {
    name: "Api_Exception",
    components: {},
    data() {
        return {
            score: "",
            data: {
                exceptionDesc: "",
            },
            questionnierId: "",
        };
    },
    beforeMount() {
        // if (localStorage.getItem("json") != null) {
        //     this.jsonstr = localStorage.getItem("json");
        //     localStorage.removeItem("json");
        // }
        var token = localStorage.getItem("token");
        this.questionnierId =
            localStorage.getItem("questionnierId") == null
                ? null
                : localStorage.getItem("questionnierId");
        localStorage.removeItem("questionnierId");
        this.score =
            localStorage.getItem("apiScore") == null
                ? null
                : localStorage.getItem("apiScore");
        localStorage.removeItem("apiScore");
    },
    mounted() {
        document.getElementById("resion_message").style.display = "none";
    },
    methods: {
        showExceptionMessage() {
            document.getElementById("resion_message").style.display = "table";
        },
        applyException() {
            document.getElementById("applyException").disabled = true;
            if (this.data.exceptionDesc == "") {
                this.$fire({
                    type: "error",
                    title: "Please enter why you think this is an API!!!!",
                    showConfirmButton: false,
                    timer: 2000,
                }).then(() => {
                    document.getElementById("apiExcDesc").focus();
                    document.getElementById("applyException").disabled = false;
                });
            } else {
                var dataCol = this.data;
                dataCol["qId"] = this.questionnierId;
                dataCol["status"] = "ex";
                dataCol["callFrom"] = "applyException";
                var token = localStorage.getItem("token");
                dataCol["token"] = token;
                this.axios.post("init/v1/updateApiStatus", dataCol).then((res) => {
                    console.log(res);
                    this.$fire({
                        type: "success",
                        title: "Data saved Successfully",
                        showConfirmButton: false,
                        timer: 2000,
                    }).then(() => {
                        this.data.exceptionDesc = "";
                        document.getElementById("applyException").disabled = false;
                    });
                });
            }
        },
    },
};
</script>
