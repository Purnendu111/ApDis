<template>
    <div v-if="items !== null">
        <b-row id="searchBar">
            <b-col>
                <b-form-input
                    id="filter"
                    name="filter"
                    v-model="filter"
                    placeholder="search"
                    type="search"
                    trim
                ></b-form-input>
            </b-col>
            <b-col
                ><b-form-select
                    id="domain"
                    name="domain"
                    class="paddingLeft10"
                    style="width: 70px !important"
                    menu-class="w-100"
                    v-model="perPage"
                >
                    <b-form-select-option :value="10">10</b-form-select-option>
                    <b-form-select-option :value="25">25</b-form-select-option>
                    <b-form-select-option :value="50">50</b-form-select-option>
                    <b-form-select-option :value="100">100</b-form-select-option>
                </b-form-select>
            </b-col>
        </b-row>
        <b-row id="dataTable">
            <b-col>
                <b-table
                    striped
                    hover
                    :sticky-header="tBody_Ht"
                    :fields="fields"
                    :items="items"
                    :filter="filter"
                    :per-page="perPage"
                    :current-page="currPage"
                    :tbody-tr-class="rowClass"
                >
                    <template #cell(descripction)="data">
                        <b-button size="sm" @click="data.toggleDetails" class="mr-2">
                            {{ data.detailsShowing ? "Hide" : "Show" }}
                            <span v-if="data.item.status == 'ex'">Descripctions</span
                            ><span v-else>Descripction</span>
                        </b-button>
                    </template>
                    <template #cell(edit)="data">
                        <b-icon
                            v-if="data.item.status === 'er' || data.item.status === 'ex'"
                            :text="data.item.status"
                            v-on:click="editData(data.item._id)"
                            icon="pencil"
                            aria-hidden="true"
                        >
                        </b-icon>
                    </template>

                    <template #cell(delete)="data">
                        <b-icon
                            v-on:click="deleteitem(data.item._id)"
                            icon="trash"
                            aria-hidden="true"
                        >
                        </b-icon>
                    </template>
                    <template #row-details="data">
                        <b-card>
                            <b-row class="mb-2">
                                <b-col sm="3" class="text-sm-right"
                                    ><b>Description:</b></b-col
                                >
                                <b-col>{{ data.item.desc }}</b-col>
                            </b-row>
                            <b-row class="mb-2" v-if="data.item.status === 'ex'">
                                <b-col sm="3" class="text-sm-right"
                                    ><b>Exception Description:</b></b-col
                                >
                                <b-col>{{ data.item.exceptionDesc }}</b-col>
                            </b-row>
                            <b-button size="sm" @click="data.toggleDetails"
                                >Hide Details</b-button
                            >
                        </b-card>
                    </template>
                </b-table>
            </b-col>
        </b-row>
        <b-row id="pagination">
            <b-col>
                <b-pagination
                    v-model="currPage"
                    :total-rows="rows"
                    :per-page="perPage"
                    style="margin-bottom: 0px !important"
                ></b-pagination>
            </b-col>
        </b-row>
    </div>
    <div v-else>
        <center>
            <h3 style="position: absolute; left: 45% !important; top: 45% !important">
                No records Found
            </h3>
        </center>
    </div>
</template>
<script>
export default {
    name: "Api_List",
    beforeMount() {
        var token = localStorage.getItem("token");
        if (token == null) {
            this.$router.push({
                path: "/login",
            });
        } else {
            var data = {
                token: token,
            };
            this.axios
                .post("signup/v1/userInfo", data)
                .then((res) => {
                    this.callData();
                })
                .catch((err) => {
                    localStorage.clear();
                    this.$router.push({
                        path: "/login",
                    });
                });
        }
    },
    data() {
        return {
            filter: "",
            tBody_Ht: "",
            perPage: "10",
            currPage: "1",
            indexId: "",
            items: "",
            fields: [
                "index",
                { key: "api_name", label: "Api Name", sortable: true },
                { key: "domain", label: "Domain", sortable: true },
                { key: "save_time", label: "Date" },
                {
                    key: "status",
                    formatter: (value) => {
                        if (value == "su") {
                            return "Success";
                        } else if (value == "er") {
                            return "error";
                        } else if (value == "ex") {
                            return "Applied for Exception";
                        } else if (value == "rj") {
                            return "Rejected";
                        }
                    },
                },
                { key: "descripction" },
                {
                    key: "edit",
                },
                { key: "delete" },
            ],
        };
    },
    mounted() {
        var self = this;
        window.addEventListener(
            "resize",
            function () {
                self.tbodyHt();
            },
            true
        );
        self.tbodyHt();
    },
    computed: {
        rows() {
            if (this.items !== null) {
                return this.items.length;
            }
        },
    },
    methods: {
        rowClass(item, type) {
            if (!item || type !== "row") return;
            if (item.status === "su") {
                return "table-success";
            } else if (item.status === "ex" || item.status === "er") {
                return "table-warning";
            } else if (item.status === "rj") {
                return "table-danger";
            }
        },
        tbodyHt() {
            var h = window.innerHeight,
                searchBarContainerHt = document.getElementById("searchBar").offsetHeight,
                navDivContainerHt = document.getElementById("navDivContainer")
                    .offsetHeight,
                paginationContainerHt = document.getElementById("pagination")
                    .offsetHeight;
            navDivContainerHt = "0" ? "66" : navDivContainerHt;
            this.tBody_Ht =
                parseFloat(h) -
                parseFloat(searchBarContainerHt) -
                parseFloat(paginationContainerHt) -
                parseFloat(navDivContainerHt) -
                15 +
                "px";
            document.getElementById("dataTable").style.height =
                parseFloat(h) -
                parseFloat(searchBarContainerHt) -
                parseFloat(paginationContainerHt) -
                parseFloat(navDivContainerHt) -
                10 +
                "px";
        },
        callData() {
            var token = localStorage.getItem("token");
            var data = {
                token: token,
            };
            this.axios.post("init/v1/getAPIByUsername", data).then((response) => {
                this.items = response.data;
                console.log(this.domainData);
                for (var i = 0; i < this.items.length; i++) {
                    this.items[i]["index"] = parseInt(i) + 1;
                }
            });
        },
        deleteitem(id) {
            let self = this;
            self.$fire({
                title: "Are you sure?",
                text: "You won't be able to revert this!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, delete it!",
            }).then((result) => {
                if (result.value == true) {
                    var dataCol = {};
                    dataCol["qId"] = id;
                    dataCol["callFrom"] = "deleteData";
                    var token = localStorage.getItem("token");
                    dataCol["token"] = token;
                    console.log(dataCol);
                    self.axios.post("init/v1/updateApiStatus", dataCol).then((res) => {
                        console.log(res);
                        self.$fire({
                            type: "success",
                            title: "Data deleted Successfully",
                        }).then(() => {
                            self.callData();
                        });
                    });
                }
            });
        },
        editData(id) {
            var dataCol = {};
            dataCol["id"] = id;
            var token = localStorage.getItem("token");
            dataCol["token"] = token;
            this.axios.post("init/v1/getAPIById", dataCol).then((res) => {
                console.log(res);
                this.$fire({
                    title: "Update Your Exception Description for",
                    html:
                        "<strong>API Name: <u>" +
                        res.data.api_name +
                        "</u></strong><br><strong>Domain Name: <u>" +
                        res.data.domain +
                        "</u></strong>",
                    input: "textarea",
                    inputValue:
                        res.data.exceptionDesc == "" ||
                        res.data.exceptionDesc == undefined ||
                        res.data.exceptionDesc == null
                            ? ""
                            : res.data.exceptionDesc,
                    value: "test",
                    width: "80%",
                    inputAttributes: {
                        autocapitalize: "off",
                    },
                    showCancelButton: true,
                    confirmButtonText: "Submit",
                    showLoaderOnConfirm: true,
                    preConfirm: (value) => {
                        if (value !== "" && value !== undefined && value !== null) {
                            dataCol["exceptionDesc"] = value;
                            dataCol["qId"] = id;
                            dataCol["status"] = "ex";
                            dataCol["callFrom"] = "applyException";
                            return this.axios
                                .post("init/v1/updateApiStatus", dataCol)
                                .then((response) => {
                                    return response;
                                });
                        }
                    },
                }).then((result) => {
                    if (
                        result.value == "" ||
                        result.value == undefined ||
                        result.value == null
                    ) {
                        this.$fire({
                            type: "error",
                            title: "Data not Updated",
                        });
                    } else {
                        this.$fire({
                            type: "success",
                            title: "Data update Successfully",
                        }).then(() => {
                            this.callData();
                        });
                    }
                });
            });
        },
    },
};
</script>
