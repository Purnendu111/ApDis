<template>
    <div class="home">
        <div
            style="
                margin-left: 30px !important;
                margin-right: 30px !important;
                margin-bottom: 10px !important;
            "
        >
            <div class="tableCstm">
                <div class="tr">
                    <div class="td" style="width: 100% !important">
                        <div class="tableCstm">
                            <div class="tr">
                                <div
                                    class="td paddingright40"
                                    style="width: 50% !important"
                                >
                                    <div role="group">
                                        <label for="domain" class="paddingBottom10"
                                            >My APIs:</label
                                        ><br />
                                        <b-form-select
                                            id="domain"
                                            text="Select Domain"
                                            name="domain"
                                            class="input paddingLeft10"
                                            menu-class="w-100"
                                            style="
                                                width: 83% !important;
                                                height: 40px !important;
                                            "
                                            @change="onChange($event)"
                                            v-model="api_Select"
                                        >
                                            <b-form-select-option :value="null"
                                                >Please select Api
                                                Name</b-form-select-option
                                            >
                                            <b-form-select-option
                                                v-for="item in apiData"
                                                v-bind:key="item._id"
                                                menu-class="w-100"
                                                :value="item._id"
                                                >{{ item.api_name }}</b-form-select-option
                                            >
                                        </b-form-select>
                                    </div>
                                </div>
                            </div>
                            <div class="tr">
                                <div class="td">
                                    <div role="group">
                                        <label for="API_name" class="paddingBottom10"
                                            >Description :</label
                                        >
                                        <b-form-textarea
                                            rows="4"
                                            no-resize
                                            id="apiDescription"
                                            name="apiDescription"
                                            v-model="apiDescription"
                                        ></b-form-textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div
            class="bv-example-row"
            style="
                padding-left: 0px !important;
                margin-right: 65px !important;
                margin-left: 30px !important;
            "
        >
            <b-row>
                <b-col style="width: 50% !important">
                    <b-card
                        no-body
                        style="position: relative; max-width: 40rem; bg-color: #cccaca"
                    >
                        <b-tabs v-model="tabsIndex" cards>
                            <b-tab
                                title="SWAGGER INPUT"
                                :title-link-class="linkClass(0)"
                                active
                            >
                                <textarea
                                    v-model="jsonstr"
                                    rows="8"
                                    class="form-control"
                                    ref="jsonText"
                                    style="resize: none"
                                    placeholder="Paste or type Swaager Specification here..."
                                ></textarea>
                            </b-tab>
                            <b-tab title="URL" :title-link-class="linkClass(1)">
                                <div class="input-group" style="color: #000000">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">OAS URL</span>
                                    </div>
                                    <input
                                        type="text"
                                        class="form-control"
                                        v-model="swag_url"
                                        aria-label="With textarea"
                                    /><br />
                                    <button @click="fetchData()">Check File</button>
                                </div>
                            </b-tab>
                        </b-tabs>
                    </b-card>
                </b-col>
                <b-col>
                    <b-card
                        no-body
                        style="
                            position: relative;
                            left: 40px;
                            width: 44rem;
                            height: 250px;
                            overflow: auto;
                        "
                        v-show="bool"
                    >
                        <b-tabs
                            v-model="tabIndex"
                            cards
                            width="40rem"
                            style="align: justify"
                        >
                            <b-tab
                                title="VALIDATION REPORT"
                                :title-link-class="link(0)"
                                active
                                style="height: 170px !important"
                            >
                                <table
                                    class="table-responsive"
                                    style="width: 98%; margin-left: 10px"
                                >
                                    <thead
                                        class="thead-light"
                                        style="
                                            background-color: rgb(142 69 176 / 0.08);
                                            height: 35px;
                                            text-align: left;
                                        "
                                    >
                                        <th>#</th>
                                        <th>Title</th>
                                        <th>Description</th>
                                        <th>Type</th>
                                    </thead>
                                    <tbody v-cloak>
                                        <tr
                                            v-for="(a, index) in violation_res.violations"
                                            :key="a.title"
                                            style="background-color: #f8f8f8"
                                        >
                                            <td class="table-columns">{{ index + 1 }}</td>
                                            <td class="table-columns">{{ a.title }}</td>
                                            <td class="table-columns">
                                                {{ a.description }}
                                            </td>
                                            <td class="table-columns">
                                                {{ a.violation_type }}
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </b-tab>
                            <b-tab
                                title="DETAILED RESULT"
                                style="height: 170px !important"
                                :title-link-class="link(1)"
                            >
                                <h6
                                    class="card-header"
                                    style="
                                        text-align: left;
                                        color: rgb(100 34 131);
                                        font-size: 16px;
                                        font-weight: 600;
                                    "
                                    v-show="count != 0"
                                >
                                    #NO. OF VIOLATIONS :&nbsp;{{ count }}
                                </h6>
                                <table
                                    class="table-responsive"
                                    style="width: 98%; margin-left: 10px"
                                >
                                    <thead
                                        class="thead-light"
                                        style="
                                            background-color: rgb(142 69 176 / 0.08);
                                            height: 35px;
                                            text-align: left;
                                        "
                                    >
                                        <th>#</th>
                                        <th>Error Title</th>
                                        <th>Description of Error</th>
                                        <th>Error Solution</th>
                                    </thead>
                                    <tbody v-cloak>
                                        <tr
                                            v-for="(a, index) in violation_res.violations"
                                            :key="a.title"
                                            style="background-color: #f8f8f8"
                                        >
                                            <td class="table-columns">{{ index + 1 }}</td>
                                            <td class="table-columns">{{ a.title }}</td>
                                            <td class="table-columns">
                                                {{ a.description }}
                                            </td>
                                            <td class="table-columns">
                                                <span v-if="a.key_name !== undefined">{{
                                                    a.key_name
                                                }}</span
                                                >&nbsp;must be&nbsp;<span
                                                    v-if="a.key_value == '*'"
                                                    >provided</span
                                                ><span v-else-if="a.key_value >= 0"
                                                    >{{
                                                        a.key_value
                                                    }}&nbsp;parameters</span
                                                ><span v-else>{{ a.key_value }}</span>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </b-tab>

                            <b-tab
                                title="SWAGGER UI"
                                :title-link-class="link(2)"
                                @click="sawgg()"
                                style="
                                    height: 170px !important;
                                    overflow-y: auto !important;
                                "
                            >
                                <div class="swagger" id="swaggerUi"></div>
                            </b-tab>
                            <b-tab
                                title="ENABLED RULES"
                                :title-link-class="link(3)"
                                @click="sawgg()"
                                style="height: 170px !important"
                            >
                                <table
                                    class="table-responsive"
                                    style="width: 98%; margin-left: 10px"
                                >
                                    <thead
                                        class="thead-light"
                                        style="
                                            background-color: rgb(142 69 176 / 0.08);
                                            height: 35px;
                                            text-align: left;
                                        "
                                    >
                                        <th>#</th>
                                        <th>Title</th>
                                        <th>Type</th>
                                        <th>Code</th>
                                    </thead>
                                    <tbody v-cloak>
                                        <tr
                                            v-for="(a, index) in this.enabled_rules"
                                            :key="a.title"
                                            style="background-color: #f8f8f8"
                                        >
                                            <td class="table-columns">{{ index + 1 }}</td>
                                            <td class="table-columns">{{ a.title }}</td>
                                            <td class="table-columns">{{ a.type }}</td>
                                            <td class="table-columns">{{ a.code }}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </b-tab>
                            <p
                                style="
                                    text-align: center;
                                    color: rgb(100 34 131);
                                    margin-bottom: 5px;
                                "
                            >
                                Must Rules:{{ muste }},&nbsp;Should Rules:{{
                                    shoulde
                                }},&nbsp;May Rules:{{ maye }},&nbsp;Hint Rules:{{ hinte }}
                            </p>
                        </b-tabs>
                    </b-card>
                </b-col>
            </b-row>
        </div>
        <p style="float: left; margin-left: 30px !important; margin-top: 10px !important">
            <input
                type="file"
                ref="myFile"
                @change="selectedFile"
                style="display: none; border-radius: 0.5em; border: transprant"
            />
            <b-button
                style="background: #cfcdcd; border-color: #cfcdcd; color: black"
                @click="$refs.myFile.click()"
                >Browse</b-button
            >
            &nbsp;
            <b-button style="background: #583888; color: #ffffff" @click="submitreq"
                >Validate</b-button
            >
            &nbsp;
            <b-button
                style="background: #cfcdcd; border-color: #cfcdcd"
                @click="savedraft"
                >Save as Draft</b-button
            >
            &nbsp;
            <b-button
                style="background: #583888; color: #ffffff"
                v-if="count === 0"
                @click="pubapi"
                >Publish</b-button
            >
        </p>
    </div>
</template>

<script>
// @ is an alias to /src
//import HelloWorld from '@/components/HelloWorld.vue'
//import VueJsonPretty from 'vue-json-pretty'
import SwaggerUI from "swagger-ui";
import "swagger-ui/dist/swagger-ui.css";

export default {
    name: "Home",

    components: {
        //   HelloWorld
        //VueJsonPretty
    },
    props: ["id"],
    data: function () {
        return {
            data: "",
            apiData: "",
            apiDescription: "",
            api_Select: null,
            jsonstr:
                '[\n\t{\n\t"id": 1,\n\t"title": "john doe",\n\t"active": true\n\t}\n]',
            jsonerror: "",
            v_result: "",
            swag_url: "",
            violation_res: "",
            tabIndex: 0,
            tabsIndex: 0,
            count: 0,
            rules: "",
            bool: false,
            isUsere: "",
            userRole: "",
            enabled_rules: "",
            hinte: 0,
            muste: 0,
            shoulde: 0,
            maye: 0,
            email: "",
            str: "",
        };
    },
    computed: {
        prettyFormat: function () {
            // reset error
            this.jsonerror = "";
            let jsonValue = "";
            try {
                // try to parse
                jsonValue = JSON.parse(this.jsonstr);
            } catch (e) {
                this.jsonerror = JSON.stringify(e.message);
                var textarea = this.$refs.jsonText;
                if (this.jsonerror.indexOf("position") > -1) {
                    // highlight error position
                    var positionStr = this.jsonerror.lastIndexOf("position") + 8;
                    var posi = parseInt(
                        this.jsonerror.substr(
                            positionStr,
                            this.jsonerror.lastIndexOf('"')
                        )
                    );
                    if (posi >= 0) {
                        textarea.setSelectionRange(posi, posi + 1);
                    }
                }
                return "";
            }
            return JSON.stringify(jsonValue, null, 2);
        },

        swgg: function () {
            SwaggerUI({
                dom_id: "#swaggerUi",
                spec: JSON.parse(this.jsonstr),
            });
        },
    },
    filters: {
        pretty: function (value) {
            return JSON.stringify(JSON.parse(value), null, 2);
        },
    },

    created() {
        // this.val = JSON.stringify(this.data);

        console.log(this.$route.params);
        // this.$http
        //     .get("http://localhost:8001/apirules")
        //     .then((response) => {
        //         this.rules = response.data.data.rules;
        //         this.enabled_rules = this.rules.filter((rule) => rule.is_active === true);
        //         console.log(response.data);
        //     })
        //     .catch(function (error) {
        //         console.log(error);
        //     });
    },
    watch: {
        selectableType(newVal) {
            this.renderOK = false;
            if (newVal === "single") {
                this.value = "res.error";
            } else if (newVal === "multiple") {
                this.value = ["res.error", "res.data[0].title"];
            }
            this.$nextTick(() => {
                this.renderOK = true;
            });
        },
    },
    mounted() {
        // const spec = require('../path/to/my/spec.json');
        SwaggerUI({
            spec: this.jsonstr,
            dom_id: "#swagger",
        });
    },
    beforeMount() {
        // if (localStorage.getItem("json") != null) {
        //     this.jsonstr = localStorage.getItem("json");
        //     localStorage.removeItem("json");
        // }
        var token = localStorage.getItem("token");
        if (token == null) {
            this.$router.push({
                path: "/login",
            });
        } else {
            var data = {
                token: token,
            };
            this.axios
                .post("init/v1/getAPIByUsername", data)
                .then((res) => {
                    var questionnierId =
                        localStorage.getItem("questionnierId") == null
                            ? null
                            : localStorage.getItem("questionnierId");
                    localStorage.removeItem("questionnierId");
                    if (questionnierId != null) {
                        this.api_Select = questionnierId;
                        this.onChange(questionnierId);
                    } else {
                        this.api_Select = null;
                    }
                    this.apiData = res.data;
                })
                .catch((err) => {
                    localStorage.clear();
                    this.$router.push({
                        path: "/login",
                    });
                });
        }
    },
    methods: {
        onChange(event) {
            var data = {
                id: event,
            };
            this.axios.post("init/v1/getAPIById", data).then((res) => {
                this.apiDescription = res.data.desc;
                console.log(this.apiDescription.desc);
            });
        },
        link(idx) {
            if (this.tabIndex === idx) {
                return ["bg-info", "text-light"];
            } else {
                return ["text-info"];
            }
        },
        linkClass(idx) {
            if (this.tabsIndex === idx) {
                return ["bg-light", "text-dark"];
            } else {
                return ["text-dark"];
            }
        },
        savedraft() {
            this.email = localStorage.email;
            // this.axios
            //     .post("http://localhost:5000/insert_apis", {
            //         spec_details: this.jsonstr,
            //         email: this.email,
            //         orgname: "ORG1",
            //     })
            //     .then((resp) => {
            //         console.log(resp.data);
            //         //this.v_result=JSON.stringify(resp.data);
            //         // var obj = JSON.parse(resp.data);
            //         var pretty = JSON.stringify(resp.data, undefined, 6);
            //         this.v_result = pretty;
            //     });
        },
        pubapi() {
            // this.axios
            //     .post("http://localhost:5000/apii", {
            //         spec_details: this.jsonstr,
            //         email: localStorage.email,
            //         orgname: localStorage.current_org,
            //     })
            //     .then((response) => {
            //         this.str = response.data;
            //         console.log(this.orgs);
            //     })
            //     .catch(function (error) {
            //         console.log(error);
            //     });
        },
        selectedFile() {
            console.log("selected a file");
            console.log(this.$refs.myFile.files[0]);

            let file = this.$refs.myFile.files[0];
            console.log(file.type);
            if (!file || file.type !== "application/json") return;

            // Credit: https://stackoverflow.com/a/754398/52160
            let reader = new FileReader();
            reader.readAsText(file, "UTF-8");
            reader.onload = (evt) => {
                this.jsonstr = evt.target.result;
            };
            reader.onerror = (evt) => {
                console.error(evt);
            };
        },
        submitreq() {
            console.log(this.jsonstr);
            //let currentObj = this;
            // this.axios
            //     .post("http://localhost:8001/uploader", {
            //         spec_details: this.jsonstr,
            //     })
            //     .then((resp) => {
            //         console.log(resp.data);
            //         //this.v_result=JSON.stringify(resp.data);
            //         // var obj = JSON.parse(resp.data);
            //         var pretty = JSON.stringify(resp.data, undefined, 6);
            //         this.violation_res = resp.data;
            //         this.muste = this.violation_res.violations.filter(
            //             (rule) => rule.violation_type == "MUST"
            //         ).length;
            //         this.maye = this.violation_res.violations.filter(
            //             (rule) => rule.violation_type == "MAY"
            //         ).length;
            //         this.shoulde = this.violation_res.violations.filter(
            //             (rule) => rule.violation_type == "SHOULD"
            //         ).length;
            //         this.hinte = this.violation_res.violations.filter(
            //             (rule) => rule.violation_type == "HINT"
            //         ).length;
            //         this.count = this.violation_res.violations.length;
            //         this.v_result = pretty;
            //     });
            //enabled rules

            this.bool = true;
        },

        sawgg() {
            console.log("In Swagger Ui Fuc");
            SwaggerUI({
                dom_id: "#swaggerUi",
                spec: JSON.parse(this.jsonstr),
            });
        },
        fetchData() {
            console.log("Fetch data from url" + this.swag_url);
            // this.$http
            //     .get(this.swag_url)
            //     .then((response) => {
            //         this.jsonstr = JSON.stringify(response.data);
            //         console.log(response.data);
            //     })
            //     .catch(function (error) {
            //         console.log(error);
            //     });
        },
        handleClick(path, data, treeName = "") {
            console.log("click: ", path, data, treeName);
            this.itemPath = path;
            this.itemData = !data ? data + "" : data; // 处理 data = null 的情况
        },
        handleChange(newVal, oldVal) {
            console.log("newVal: ", newVal, " oldVal: ", oldVal);
        },
        customLinkFormatter(data, key, parent, defaultFormatted) {
            if (data.startsWith("http://")) {
                return `<a style="color:red;" href="${data}" target="_blank">"${data}"</a>`;
            } else {
                return defaultFormatted;
            }
        },
    },
};
</script>

<style lang="less" scoped>
html,
body {
    margin: 0;
    background-color: #ffffff;
}
.example {
    position: relative;
    padding: 0 15px;
    margin: 0 auto;
}

table {
    overflow-y: scroll;
    height: 180px;
    display: block;
}
.example-box {
    margin: 0 -15px;
    overflow: hidden;
    h3 {
        display: inline-block;
    }

    .block {
        float: left;
        padding: 0 15px;
        width: 50%;
        box-sizing: border-box;
    }

    input,
    select,
    textarea {
        padding: 3px 8px;
        box-sizing: border-box;
        border-radius: 5px;
        border: 1px solid #ffffff;
        font-family: inherit;
        &:focus {
            outline: none;
            border-color: #cccaca;
            box-shadow: 0 0 3px #ffffff;
        }
    }
    textarea {
        width: 100%;
        height: 150px;
        resize: vertical;
        color: #17a2b8;
    }

    .options {
        font-size: 14px;
    }
    .table-columns {
        padding-left: 10px;
        border-right: 1px solid rgba(168, 168, 168, 0.25);
        border-bottom: 1px solid #ffffff;
        font-weight: 550;
        font-size: 13px;
        text-align: left;
    }
    th {
        width: 0.3%;
        color: rgb(100 34 131);
        padding-left: 10px;
        border-right: 1px solid rgba(168, 168, 168, 0.25);
        letter-spacing: 1.8px;
        font-size: 13px;
        border-bottom: 1px solid #ffffff;
        opacity: 0.9;
    }
}
</style>
