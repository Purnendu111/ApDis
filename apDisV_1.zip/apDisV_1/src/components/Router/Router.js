import Vue from 'vue'
import VueRouter from 'vue-router'

import Questionnaire from '../API_Initiate/Questionnaire.vue';
import Api_Exception from '../API_Initiate/Api_Exception.vue';
import myapiList from '../API_Initiate/myapiList.vue';
import ExceptionList from '../API_Initiate/ExcepList.vue';
import API_Linter from '../API_Linter/api_linter.vue'
import Api_Catalogue from '../API_Initiate/Api_Catalogue.vue';

import SignInSignUpReset from "../login/components/SignInSignUpReset.vue";

Vue.use(VueRouter)

const routes = 
[  {
        path: '/questionnaire',
        name: "Questionnaire",
        component: Questionnaire
    },
    {
        path: '/api_exception',
        name: "Api_Exception",
        component: Api_Exception
    }, {
        path: '/exceptionList',
        name: "ExceptionList",
        component: ExceptionList
    }, {
        path: '/login',
        name: "Login",
        component: SignInSignUpReset
    }, {
        path: '/api_linter',
        name: "API_Linter",
        component: API_Linter,
        props: true,
    }, {
        path: '/myapilist',
        name: "Api_List",
        component: myapiList,
    } , {
        path: '/api_cata',
        name: "Api_Catalogue",
        component: Api_Catalogue
    }
]

const router = new VueRouter({
    mode: 'history',
    base: process.env.BASE_URL,
    routes
})

export default router