

const { MongoClient } = require('mongodb');
const mongoose = require('mongoose');
const uri = "mongodb+srv://07vigita:qwerty123@cluster0.lymz3.mongodb.net/ap_dis?retryWrites=true&w=majority";

var dbConnection = undefined;

exports.mongodbService = (cb, err) => {
    if (dbConnection != undefined) {
        console.log("Using existing connection...");
        cb(dbConnection);
    } else {
        try {
            // Connect to the MongoDB cluster
            mongoose.connect(
                uri,
                { useNewUrlParser: true, useUnifiedTopology: true }
            ).then((dbCon) => {
                console.log("Returning new collection...");
                dbConnection = dbCon;
                cb(dbConnection);
            });
            
        } catch (e) {
            console.log("could not connect");
            dbConnection = undefined;
        }
    }
}
